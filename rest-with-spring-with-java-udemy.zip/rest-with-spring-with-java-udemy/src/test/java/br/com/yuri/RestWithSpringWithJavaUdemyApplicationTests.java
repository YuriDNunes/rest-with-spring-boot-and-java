package br.com.yuri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringWithJavaUdemyApplicationTests {

	@Test
	void contextLoads() {
	}

}
