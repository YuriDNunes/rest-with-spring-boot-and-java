package br.com.yuri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithSpringWithJavaUdemyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithSpringWithJavaUdemyApplication.class, args);
	}

}
